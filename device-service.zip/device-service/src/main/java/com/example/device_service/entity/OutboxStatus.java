package com.example.device_service.entity;

public enum OutboxStatus {
    PENDING, PROCESSED
}

